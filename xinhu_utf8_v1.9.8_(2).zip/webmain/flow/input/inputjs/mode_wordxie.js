//流程模块【wordxie.文档协作】下录入页面自定义js页面,初始函数
function initbodys(){
	
}