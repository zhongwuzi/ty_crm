//流程模块【hrkaohem.考核项目】下录入页面自定义js页面,初始函数
function initbodys(){
	
}