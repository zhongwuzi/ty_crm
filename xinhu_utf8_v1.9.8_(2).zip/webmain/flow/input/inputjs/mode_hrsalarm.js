//流程模块【hrsalarm.薪资模版】下录入页面自定义js页面,初始函数
function initbodys(){
	
}