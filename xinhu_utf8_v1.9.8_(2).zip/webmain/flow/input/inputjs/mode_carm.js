//初始函数
function initbodys(){
	
}