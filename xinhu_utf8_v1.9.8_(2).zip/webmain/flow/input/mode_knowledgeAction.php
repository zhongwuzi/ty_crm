<?php
/**
*	此文件是流程模块【knowledge.知识】对应接口文件。
*	可在页面上创建更多方法如：public funciton testactAjax()，用js.getajaxurl('testact','mode_knowledge|input','flow')调用到对应方法
*/ 
class mode_knowledgeClassAction extends inputAction{
	
	
}	
			