<?php
/**
*	此文件是流程模块【knowtiku.题库】对应接口文件。
*	可在页面上创建更多方法如：public funciton testactAjax()，用js.getajaxurl('testact','mode_knowtiku|input','flow')调用到对应方法
*/ 
class mode_knowtikuClassAction extends inputAction{
	
	/**
	*	
	*/
	protected function savebefore($table, $arr, $id, $addbo){
		
	}
	
}	
			